import 'package:flutter/material.dart';

const primaryColor = Color(0xFF5A4FCF);
